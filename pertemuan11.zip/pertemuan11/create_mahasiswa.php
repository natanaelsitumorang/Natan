<?php 

    $connection = new mysqli("localhost","root","","latihan");
    $title      = $_POST['title'];
    $kutipan    = $_POST['kutipan'];
    $date       = date('Y-m-d');

    $result = mysqli_query($connection, "insert into note_app set title='$title', kutipan='$kutipan', date='$date'");

    if($result){
        echo json_encode([
            'message' => 'Data input mahasiswa successfully'
        ]);
    }else{
        echo json_encode([
                'message' => 'Data mahasiswa Failed to input'
        ]);  
    }
        
